let firstNumber = Number(prompt('Enter first price!'));

let secondNumber = Number(prompt('Enter second price!'));


alert(firstNumber + secondNumber);